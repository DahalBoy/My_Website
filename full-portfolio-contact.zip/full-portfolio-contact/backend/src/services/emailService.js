const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.EMAIL_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

async function sendNotificationEmail({ name, email, phone, subject, message }) {
  const html = `
  <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;border:1px solid #e0e0e0;border-radius:8px;overflow:hidden">
    <div style="background:#1a1a2e;padding:24px 28px">
      <h2 style="color:#fff;margin:0;font-size:20px">📬 New Portfolio Message</h2>
    </div>
    <div style="padding:24px 28px">
      <table style="width:100%;border-collapse:collapse;font-size:15px">
        <tr><td style="padding:8px 0;color:#666;width:80px"><b>Name</b></td><td style="padding:8px 0">${escapeHtml(name)}</td></tr>
        <tr><td style="padding:8px 0;color:#666"><b>Email</b></td><td style="padding:8px 0"><a href="mailto:${escapeHtml(email)}" style="color:#4a90e2">${escapeHtml(email)}</a></td></tr>
        ${phone ? `<tr><td style="padding:8px 0;color:#666"><b>Phone</b></td><td style="padding:8px 0">${escapeHtml(phone)}</td></tr>` : ''}
        <tr><td style="padding:8px 0;color:#666"><b>Subject</b></td><td style="padding:8px 0">${escapeHtml(subject || '(no subject)')}</td></tr>
      </table>
      <div style="margin-top:16px;background:#f7f7f7;border-left:4px solid #1a1a2e;padding:14px 18px;border-radius:4px">
        <p style="margin:0;white-space:pre-wrap;font-size:15px;line-height:1.6">${escapeHtml(message)}</p>
      </div>
      <p style="margin-top:20px;font-size:12px;color:#aaa">Received ${new Date().toUTCString()} · Portfolio Contact API</p>
    </div>
  </div>`;

  await transporter.sendMail({
    from: `"Portfolio Contact" <${process.env.EMAIL_USER}>`,
    to: process.env.OWNER_EMAIL,
    replyTo: email,
    subject: `[Portfolio] New message from ${name}`,
    html,
    text: `Name: ${name}\nEmail: ${email}\n${phone ? `Phone: ${phone}\n` : ''}Subject: ${subject || '(no subject)'}\n\n${message}`,
  });

  return true;
}

module.exports = { sendNotificationEmail };
