const twilio = require('twilio');

let client;
function getClient() {
  if (!client) client = twilio(process.env.TWILIO_SID, process.env.TWILIO_AUTH);
  return client;
}

async function sendSmsAlert({ name, email, message }) {
  const preview = message.length > 80 ? message.slice(0, 77) + '...' : message;
  await getClient().messages.create({
    body: `[Portfolio] New msg from ${name} (${email}): ${preview}`,
    from: process.env.TWILIO_FROM,
    to: process.env.OWNER_PHONE,
  });
  return true;
}

module.exports = { sendSmsAlert };
