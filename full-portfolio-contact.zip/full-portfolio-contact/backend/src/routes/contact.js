const express = require('express');
const router = express.Router();
const Message = require('../models/Message');
const { sendNotificationEmail } = require('../services/emailService');
const { sendSmsAlert } = require('../services/smsService');
const { contactLimiter } = require('../middleware/rateLimiter');
const { sanitizeContact } = require('../middleware/sanitize');

router.post('/', contactLimiter, sanitizeContact, async (req, res) => {
  try {
    const { name, email, phone, subject, message, _honeypot } = req.body;

    // Honeypot — bots fill this, humans don't
    if (_honeypot) return res.status(200).json({ success: true });

    // Validation
    const errors = {};
    if (!name || name.length < 2) errors.name = 'Name must be at least 2 characters.';
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.email = 'Valid email is required.';
    if (!message || message.length < 10) errors.message = 'Message must be at least 10 characters.';
    if (message && message.length > 2000) errors.message = 'Message must be under 2000 characters.';

    if (Object.keys(errors).length > 0) {
      return res.status(422).json({ error: 'Validation failed', fields: errors });
    }

    // Save to DB
    const doc = await Message.create({
      name, email,
      phone: phone || null,
      subject: subject || '(no subject)',
      message,
      ip_address: req.ip,
      status: 'unread',
    });

    // Send email (non-blocking)
    let emailSent = false, smsSent = false;
    try {
      await sendNotificationEmail({ name, email, phone, subject, message });
      emailSent = true;
    } catch (err) {
      console.error('Email error:', err.message);
    }

    // Send SMS if configured
    if (process.env.TWILIO_SID && process.env.OWNER_PHONE) {
      try {
        await sendSmsAlert({ name, email, message });
        smsSent = true;
      } catch (err) {
        console.error('SMS error:', err.message);
      }
    }

    await Message.findByIdAndUpdate(doc._id, { email_sent: emailSent, sms_sent: smsSent });

    return res.status(201).json({
      success: true,
      message: "Thanks for reaching out! I'll get back to you soon.",
    });

  } catch (err) {
    console.error('Contact error:', err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

module.exports = router;
