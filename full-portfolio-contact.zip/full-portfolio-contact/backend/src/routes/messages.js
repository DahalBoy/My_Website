const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Message = require('../models/Message');
const { requireAdminKey } = require('../middleware/auth');
const { readLimiter } = require('../middleware/rateLimiter');

router.use(requireAdminKey, readLimiter);

// GET /api/messages
router.get('/', async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (status && ['unread', 'read', 'archived'].includes(status)) filter.status = status;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const [messages, total] = await Promise.all([
      Message.find(filter).sort({ created_at: -1 }).skip(skip).limit(parseInt(limit)).lean(),
      Message.countDocuments(filter),
    ]);
    res.json({ data: messages, pagination: { page: parseInt(page), limit: parseInt(limit), total } });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch messages.' });
  }
});

// GET /api/messages/:id
router.get('/:id', async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id))
      return res.status(400).json({ error: 'Invalid ID.' });
    const msg = await Message.findByIdAndUpdate(req.params.id, { status: 'read' }, { new: true }).lean();
    if (!msg) return res.status(404).json({ error: 'Not found.' });
    res.json(msg);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch message.' });
  }
});

// PATCH /api/messages/:id
router.patch('/:id', async (req, res) => {
  try {
    const { status } = req.body;
    if (!['unread', 'read', 'archived'].includes(status))
      return res.status(422).json({ error: 'Invalid status.' });
    if (!mongoose.Types.ObjectId.isValid(req.params.id))
      return res.status(400).json({ error: 'Invalid ID.' });
    const msg = await Message.findByIdAndUpdate(req.params.id, { status }, { new: true }).lean();
    if (!msg) return res.status(404).json({ error: 'Not found.' });
    res.json(msg);
  } catch (err) {
    res.status(500).json({ error: 'Failed to update.' });
  }
});

// DELETE /api/messages/:id
router.delete('/:id', async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id))
      return res.status(400).json({ error: 'Invalid ID.' });
    const msg = await Message.findByIdAndDelete(req.params.id);
    if (!msg) return res.status(404).json({ error: 'Not found.' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete.' });
  }
});

module.exports = router;
