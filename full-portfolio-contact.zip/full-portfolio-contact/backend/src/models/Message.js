const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  name:       { type: String, required: true, trim: true, minlength: 2, maxlength: 100 },
  email:      { type: String, required: true, trim: true, lowercase: true },
  phone:      { type: String, trim: true, default: null },
  subject:    { type: String, trim: true, default: '(no subject)', maxlength: 200 },
  message:    { type: String, required: true, trim: true, minlength: 10, maxlength: 2000 },
  ip_address: { type: String, default: null },
  status:     { type: String, enum: ['unread', 'read', 'archived'], default: 'unread' },
  email_sent: { type: Boolean, default: false },
  sms_sent:   { type: Boolean, default: false },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });

module.exports = mongoose.model('Message', messageSchema);
