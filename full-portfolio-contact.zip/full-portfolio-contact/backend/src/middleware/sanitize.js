function sanitizeContact(req, res, next) {
  const fields = ['name', 'email', 'phone', 'subject', 'message'];
  for (const field of fields) {
    if (req.body[field] && typeof req.body[field] === 'string') {
      req.body[field] = req.body[field].replace(/<[^>]*>/g, '').trim();
    }
  }
  next();
}

module.exports = { sanitizeContact };
