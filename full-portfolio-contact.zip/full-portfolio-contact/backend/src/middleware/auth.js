function requireAdminKey(req, res, next) {
  const key = req.headers['x-admin-key'];
  if (!process.env.ADMIN_API_KEY) return next();
  if (!key || key !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized. Valid X-Admin-Key header required.' });
  }
  next();
}

module.exports = { requireAdminKey };
