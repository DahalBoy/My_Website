# Portfolio Contact API — Complete Deploy Guide

Two repos, two deploys. That's all.

| What | Repo | Hosting |
|------|------|---------|
| Backend API | `portfolio-contact-api` (new) | Railway (free) |
| Your portfolio | `My_Website` (existing) | GitHub Pages |

---

## PART 1 — Deploy the Backend to Railway

### Step 1: Create the GitHub repo

1. Go to https://github.com/new
2. Name: `portfolio-contact-api`
3. Visibility: Private ✅ (keeps your config safe)
4. Click **Create repository**

### Step 2: Push the backend code

Open a terminal inside the `backend/` folder from this zip:

```bash
cd backend
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/dahalboy/portfolio-contact-api.git
git push -u origin main
```

### Step 3: Deploy on Railway

1. Go to https://railway.app → sign in with GitHub
2. Click **New Project** → **Deploy from GitHub repo**
3. Select `dahalboy/portfolio-contact-api`
4. Click **Deploy Now**

### Step 4: Set environment variables on Railway

In your Railway project → **Variables** tab → add these one by one:

```
MONGODB_URI         → your MongoDB Atlas connection string (see below)
EMAIL_HOST          → smtp.gmail.com
EMAIL_PORT          → 587
EMAIL_USER          → your Gmail address
EMAIL_PASS          → your Gmail App Password (see below)
OWNER_EMAIL         → email where you receive notifications
OWNER_PHONE         → +977XXXXXXXXXX (for SMS)
TWILIO_SID          → from twilio.com/console (or leave blank to skip SMS)
TWILIO_AUTH         → from twilio.com/console (or leave blank)
TWILIO_FROM         → your Twilio phone number (or leave blank)
ADMIN_API_KEY       → any long random string (to read your messages later)
CORS_ORIGIN         → https://dahalboy.github.io
```

### Step 5: Get your Railway URL

Railway → your project → **Settings** → **Domains** → copy the URL
It will look like: `https://portfolio-contact-api.up.railway.app`

Test it:
```
https://portfolio-contact-api.up.railway.app/health
```
Should return: `{"status":"ok"}`

---

## How to get MongoDB Atlas URI (free, 5 min)

1. Go to https://mongodb.com/atlas → Create free account
2. Create a free **M0** cluster (any region)
3. **Database Access** → Add New Database User → username + password → Role: "Read and write"
4. **Network Access** → Add IP Address → Allow Access from Anywhere (`0.0.0.0/0`)
5. **Clusters** → Connect → Drivers → copy the string
6. Replace `<password>` in the string with your DB user password
7. Replace `myFirstDatabase` with `portfolio`

Final URI looks like:
```
mongodb+srv://myuser:mypassword@cluster0.abc12.mongodb.net/portfolio?retryWrites=true&w=majority
```

---

## How to get Gmail App Password (3 min)

1. Your Google Account → Security → enable **2-Step Verification** first
2. Security → **App passwords** (scroll down)
3. Select app: **Mail** → Select device: **Other** → name it "Portfolio API"
4. Copy the 16-character code (e.g. `abcd efgh ijkl mnop`)
5. Use this as `EMAIL_PASS` — NOT your real Gmail password

---

## PART 2 — Add Contact Form to Your Portfolio

### Step 1: Open `frontend/contact-section.html`

This file is your contact section. It can be opened in any browser to preview it.

### Step 2: Update the API URL

Open `frontend/contact-section.html` in a text editor.
Find this line near the bottom (inside the `<script>` block):

```js
const API_BASE = 'https://YOUR-API.up.railway.app';
```

Replace it with your actual Railway URL:
```js
const API_BASE = 'https://portfolio-contact-api.up.railway.app';
```

### Step 3: Add to your existing portfolio

Open your `My_Website/index.html` and make these 3 additions:

**A) Paste the CSS** — copy everything between `/* ── Contact Section ── */` and the closing `</style>` comment into your existing `<style>` tag (or your CSS file).

**B) Paste the HTML section** — copy the `<section id="contact">...</section>` block and paste it wherever you want the contact section in your page (usually near the bottom, before the footer).

**C) Paste the JavaScript** — copy the entire `<script>` block and paste it just before your closing `</body>` tag.

### Step 4: Update the contact links

Inside the `<section>` HTML, find and update:
```html
<a href="mailto:your@email.com">  ← replace with your real email
<a href="https://github.com/dahalboy">  ← already correct
<a href="https://linkedin.com/in/yourprofile">  ← replace with your LinkedIn
```

### Step 5: Push changes to GitHub

```bash
cd My_Website
git add .
git commit -m "Add contact form with backend API"
git push
```

GitHub Pages will auto-deploy in ~2 minutes.

---

## PART 3 — Test Everything

1. Go to https://dahalboy.github.io/My_Website/
2. Fill in the contact form → click Send Message
3. You should see "✅ Message sent!" in green
4. Check your email — you should receive a notification email
5. Optional: check your phone for the SMS

### To read your messages (admin)

Use any API tool (Hoppscotch: https://hoppscotch.io):

```
GET https://portfolio-contact-api.up.railway.app/api/messages
Header: X-Admin-Key: your_admin_api_key
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| CORS error in browser console | Make sure `CORS_ORIGIN` on Railway is exactly `https://dahalboy.github.io` (no slash at end) |
| Email not arriving | Check Gmail App Password is correct; check Railway logs |
| Railway not starting | Railway → Logs tab → look for error messages |
| Form shows "Network error" | API URL in the JS might be wrong or Railway isn't deployed yet |
| MongoDB connection error | Check that your IP `0.0.0.0/0` is allowed in Atlas Network Access |
